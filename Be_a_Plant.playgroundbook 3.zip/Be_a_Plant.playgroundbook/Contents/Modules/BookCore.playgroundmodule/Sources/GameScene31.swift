//
//  GameScene31.swift
//  BookCore
//
//  Created by Geovanna Kasemirinski da Silva on 15/04/21.
//

import Foundation
import SpriteKit

import PlaygroundSupport


public class GameScene31: SKScene{
    
//    var parts: SKSpriteNode {
//        childNode(withName: "PartsSeed") as! SKSpriteNode
//    }
    
    
    var nextNode: SKSpriteNode {
        childNode(withName: "Next") as! SKSpriteNode
    }
    
    var arrowEn: SKSpriteNode {
        childNode(withName: "arrowEn") as! SKSpriteNode
    }
    
    var endosperm: SKSpriteNode {
        childNode(withName: "endosperm") as! SKSpriteNode
    }
    var arrowEm: SKSpriteNode {
        childNode(withName: "arrowEm") as! SKSpriteNode
    }
    var embryo: SKSpriteNode {
        childNode(withName: "embryo") as! SKSpriteNode
    }
    var arrowR: SKSpriteNode {
        childNode(withName: "arrowR") as! SKSpriteNode
    }
    var arrowP: SKSpriteNode {
        childNode(withName: "arrowP") as! SKSpriteNode
    }
    var radicle: SKSpriteNode {
        childNode(withName: "radicle") as! SKSpriteNode
    }
   
    
    var plumele: SKSpriteNode {
        childNode(withName: "plumele") as! SKSpriteNode
    }
    
    
    
    override public func didMove(to view: SKView){
        backgroundColor = .init(red: 249, green: 247, blue: 247, alpha: 1)
        
        arrowEn.alpha = 0
        arrowEm.alpha = 0
        arrowR.alpha = 0
        arrowP.alpha = 0
        plumele.alpha = 0
        endosperm.alpha = 0
        embryo.alpha = 0
        radicle.alpha = 0
        
        self.arrowEn.run(.fadeAlpha(to: 1, duration: 0.3)){
            self.run(.wait(forDuration: 0.3)){
                self.endosperm.run(.fadeAlpha(to: 1, duration: 0.3)){
                    self.run(.wait(forDuration: 0.3)){
                        self.arrowEm.run(.fadeAlpha(to: 1, duration: 0.3)){
                            self.run(.wait(forDuration: 0.3)){
                                self.embryo.run(.fadeAlpha(to: 1, duration: 0.3)){
                                    self.run(.wait(forDuration: 0.3)){
                                        self.arrowR.run(.fadeAlpha(to: 1, duration: 0.3)){
                                            self.run(.wait(forDuration: 0.3)){
                                                self.radicle.run(.fadeAlpha(to: 1, duration: 0.3)){
                                                    self.arrowP.run(.fadeAlpha(to: 1, duration: 0.3)){
                                                        self.run(.wait(forDuration: 0.3)){
                                                            self.plumele.run(.fadeAlpha(to: 1, duration: 0.3))
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        
        
        
    }
    
    
    @objc static override public var supportsSecureCoding: Bool {
        // SKNode conforms to NSSecureCoding, so any subclass going
        // through the decoding process must support secure coding
        get {
            return true
        }
    }

    func touchDown(atPoint pos : CGPoint){

        if nextNode.contains(pos){
// named -> proxima tela
            let scene = GameScene32(fileNamed: "GameScene32")!
            scene.scaleMode = .aspectFit
            self.view!.presentScene(scene)
            self.removeFromParent()
        }
    }
    override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchDown(atPoint: t.location(in: self)) }
    }
    

}
