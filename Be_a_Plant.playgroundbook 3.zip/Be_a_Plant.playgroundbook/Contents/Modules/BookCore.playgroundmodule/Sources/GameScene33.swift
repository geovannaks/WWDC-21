//
//  GameScene33.swift
//  BookCore
//
//  Created by Geovanna Kasemirinski da Silva on 15/04/21.
//

import Foundation
import SpriteKit

import PlaygroundSupport


public class GameScene33: SKScene{
    
    var backg: SKSpriteNode {
        childNode(withName: "BackgroundFinal") as! SKSpriteNode
    }
    
    var nextNode: SKSpriteNode {
        childNode(withName: "Next") as! SKSpriteNode
    }
    
//    var leaf: SKSpriteNode {
//        childNode(withName: "LeafTeste") as! SKSpriteNode
//    }
//
//    var leaf1: SKSpriteNode {
//        childNode(withName: "LeafTeste1") as! SKSpriteNode
//    }
    var textFinal: SKSpriteNode {
        childNode(withName: "textFinal") as! SKSpriteNode
    }
    
    // lista de folhas
    var leaves = [SKSpriteNode]()


  
    
    
    override public func didMove(to view: SKView){
        
       // leafDown(leaf: leaf)
        //leafDown(leaf: leaf1)
       // leafDown(leaf: leaves)
        textFinal.zPosition = 10
        textFinal.alpha = 0 
        self.run(.wait(forDuration: 1.5)){
            self.textFinal.run(.fadeAlpha(to: 2, duration: 0.5))
        }
      
        for _ in 1...10 {
            
            createLeaf()
            
        }
        
        
    }
    
    
    @objc static override public var supportsSecureCoding: Bool {
        // SKNode conforms to NSSecureCoding, so any subclass going
        // through the decoding process must support secure coding
        get {
            return true
        }
    }

    func touchDown(atPoint pos : CGPoint){
        
    }
    
    
    func leafDown(leaf: SKSpriteNode){
        
        leaf.zRotation = CGFloat.random(in: 0...(CGFloat.pi * 2))
        leaf.setScale(CGFloat.random(in: 0.2...1.5))
        
        
        
        
        
        // folhas estão só caindo
        let rangeX = CGFloat.random(in: 20...200)
        
        
        
        let rangeY = CGFloat(3000)
        
        let down = SKAction.moveTo(y: -rangeY, duration: TimeInterval(CGFloat.random(in: 15...45)))
        
        
        
       
        
        let left = SKAction.moveBy(x: -rangeX, y: 0, duration: 1)
        let right = SKAction.moveBy(x: rangeX, y: 0, duration: 1)
        left.timingMode = .easeInEaseOut
        right.timingMode = .easeInEaseOut
        var sequence2: SKAction
        // sorteio 50/50
        if Int.random(in: 0...1) == 0 {
            sequence2 = SKAction.sequence([ left, right])
        }else{
            sequence2 = SKAction.sequence([ right, left])
        }
        
        
       
        let loop2 = SKAction.repeatForever(sequence2)
            
        let group = SKAction.group([down, loop2])
        
        leaf.run(group)
        
        
       
    }
    
    // gerador de folhas
    func createLeaf() {
        
        let leaf = SKSpriteNode(imageNamed: "leaf\(Int.random(in: 1...5))")
        addChild(leaf)
        
        leaves.append(leaf)
        
        // folinhas caindo de cima em posicoes aleatorias
        let posX = CGFloat.random(in: -260...280)
        // -500
        let posY = CGFloat.random(in: -500...500)
        leaf.position = CGPoint(x: posX, y: posY)
        leafDown(leaf: leaf)
        
    }
    
    
    override public func update(_ currentTime: TimeInterval){
        
        for leaf in leaves{
            
            if leaf.position.y < -500{
                leaf.removeAllActions()
                leafDown(leaf: leaf)
                leaf.position.y += 1000
                
            }
            
        }
        
    }
    
}
