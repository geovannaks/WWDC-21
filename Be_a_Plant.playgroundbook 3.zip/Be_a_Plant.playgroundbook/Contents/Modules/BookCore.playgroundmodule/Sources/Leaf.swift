import Foundation
import SpriteKit


public class Leaf {
    
    //caracteristcas basicas 
    var startPoint = CGPoint()
    var totalSize = CGFloat(0.07)
    var currentSize = CGFloat()
    var speed = CGFloat(0.009)
    
    
    // uma folha pra cada lado
    var leftLeaf = SKSpriteNode()
    var rightLeaf = SKSpriteNode()
    var scene: SKScene
    
    init(scene: SKScene, startPoint: CGPoint){
        self.scene = scene
    
        // o startPoint do caule é o startPoint da raiz level 0
        self.startPoint = startPoint
    
        leftLeaf = SKSpriteNode(imageNamed: "LeafGreen")
        rightLeaf = SKSpriteNode(imageNamed: "LeafGreen")
        
        // sem aparecer
        leftLeaf.setScale(0)
        rightLeaf.setScale(0)
        
        leftLeaf.position = (startPoint)
        rightLeaf.position = (startPoint)
        
        // brotar da borda do caule, posicao certa
        leftLeaf.anchorPoint = CGPoint(x: 0, y: 0)
        rightLeaf.anchorPoint = CGPoint(x: 0, y: 0)
        
        totalSize = CGFloat.random(in: 0.05...0.07)
        
        
        scene.addChild(leftLeaf)
        scene.addChild(rightLeaf)
        
        
    
        
    }
    func update(deltaTime: TimeInterval) {
        
        if currentSize >= totalSize{
            return
        }
        
        currentSize += CGFloat(deltaTime) * speed
        // vefericar se atingiu o tamanho total
        if currentSize > totalSize{
            currentSize = totalSize
        }
   
        leftLeaf.xScale = -currentSize
        leftLeaf.yScale = currentSize
        
        
        rightLeaf.setScale(currentSize)
    }
    
    
}
