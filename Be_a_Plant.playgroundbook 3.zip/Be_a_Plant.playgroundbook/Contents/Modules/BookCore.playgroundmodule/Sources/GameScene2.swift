//
//  GameScene2.swift
//  BookCore
//
//  Created by Geovanna Kasemirinski da Silva on 14/04/21.
//

import Foundation
import SpriteKit
import PlaygroundSupport


public class GameScene2: SKScene {
    
   
    // pega o sol e usa no codigo

    var sun: SKSpriteNode {
        childNode(withName: "Sun") as! SKSpriteNode
    }

    var leafBig: SKSpriteNode {
        childNode(withName: "LeafBig") as! SKSpriteNode
    }


    var CO2: SKSpriteNode {
        childNode(withName: "CO2") as! SKSpriteNode
    }
    var o2: SKSpriteNode {
        childNode(withName: "O2") as! SKSpriteNode
    }
    var arrow1: SKSpriteNode {
        childNode(withName: "Flecha1") as! SKSpriteNode
    }
    var arrow2: SKSpriteNode {
        childNode(withName: "Flecha2") as! SKSpriteNode
    }
    var arrowPink: SKSpriteNode {
        childNode(withName: "FlechaPink") as! SKSpriteNode
    }
    var sugarLabel: SKSpriteNode {
        childNode(withName: "Sugar") as! SKSpriteNode
    }
    var glicose: SKSpriteNode {
        childNode(withName: "Glicose") as! SKSpriteNode
    }
    

    var nextNode: SKSpriteNode {
        childNode(withName: "Next") as! SKSpriteNode
    }
    
    var move = false
    
    let maxScale: CGFloat = 0.5

    //let maxScale = CGFloat(10)
    let minScale: CGFloat = 0.1

    
    override public func didMove(to view: SKView) {
        
        backgroundColor = .init(red: 249, green: 247, blue: 247, alpha: 1)
        
        
        
//
//        let background = SKSpriteNode(texture: nil, color: #colorLiteral(red: 0.9764705882, green: 0.968627451, blue: 0.968627451, alpha: 1), size: frame.size)
//        background.position = CGPoint(x: 0, y: 0)
//        addChild(background)
//
       // background.lightingBitMask = 0b001


//        let node = sun.childNode(withName: "SKLightNode") as! SKLightNode
//        node.categoryBitMask = 0b001
//        sun.lightingBitMask = 0b001
//
//        leafBig.lightingBitMask = 0b001
//
        
        
       
        
        //APARECIMENTO GRADUAL
        
        leafBig.alpha = 0
        sun.alpha = 0
        o2.alpha = 0
        CO2.alpha = 0
        arrow1.alpha = 0
        arrow2.alpha = 0
        arrowPink.alpha = 0
        sugarLabel.alpha = 0
        glicose.alpha = 0
        
        self.sun.run(.fadeAlpha(to: 1, duration: 0.5))
        self.CO2.run(.fadeAlpha(to: 1, duration: 0.5)) {
            self.run(.wait(forDuration: 0.5)){
                self.arrow1.run(.fadeAlpha(to: 1, duration: 0.2)){
                    self.run(.wait(forDuration: 0.7)){
                        self.leafBig.run(.fadeAlpha(to: 1, duration: 0.5)){
                            self.run(.wait(forDuration: 0.5)){
                                self.arrow2.run(.fadeAlpha(to: 1, duration: 0.2)){
                                    self.run(.wait(forDuration: 0.5)){
                                    self.o2.run(.fadeAlpha(to: 1, duration: 0.5)){
                                        self.run(.wait(forDuration: 0.5)){
                                            self.glicose.run(.fadeAlpha(to: 1, duration: 0.5))
                                            self.sugarLabel.run(.fadeAlpha(to: 1, duration: 0.2)){
                                               self.run(.wait(forDuration: 0.5)){
                                                self.arrowPink.run(.fadeAlpha(to: 1, duration: 0.2)){
                                                    self.move = true
                                                }
                                                
                                           }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        }
       
        
        
        let distance = distanceBetween(first: sun.position, second: leafBig.position)
        let scale = (100 / distance)

        glicose.setScale(scale + 0.3)
        leafBig.setScale(scale) 
        
        
        
    }
    
    @objc static override public var supportsSecureCoding: Bool {
        // SKNode conforms to NSSecureCoding, so any subclass going
        // through the decoding process must support secure coding
        get {
            return true
        }
    }
    
    // clica
    func touchDown(atPoint pos : CGPoint) {
        
        
        if nextNode.contains(pos) && nextNode.alpha == 1{
            PlaygroundPage.current.navigateTo(page: .next)
        }
        
        //if botao.cont (pos)  && botao. alpha == 1
        
        //PlaygroundPage.current.navigateTo(page: .next)
        
        //PlaygroundPage.current.navigateTo(page: .next)
    }
    
    // arasta
    func touchMoved(toPoint pos : CGPoint) {
        // cada vez que o sol por arrastado para perto da folha, a folha cresce
        if sun.contains(pos) && move == true{
            sun.position = pos





            let distance = distanceBetween(first: sun.position, second: leafBig.position)
            let scale = (100 / distance)
            //˜= entre
            if minScale...maxScale ~= scale{

                leafBig.setScale(scale)
                print(scale)
            }

            let num = CGFloat(0.5)
            let glicoseScale = (100 / distance) + 0.3
            //˜= entre
            if (0)...(maxScale + num) ~= glicoseScale{
                glicose.setScale(glicoseScale)

                print(scale)
            }


        }
        
        
        
    }
    
    // solta
    func touchUp(atPoint pos : CGPoint) {
        
    }
    
    func distanceBetween(first: CGPoint, second: CGPoint) -> CGFloat {
        return CGFloat(hypotf(Float(second.x - first.x), Float(second.y - first.y)));
    }
    
    override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchDown(atPoint: t.location(in: self)) }
    }
    
    override public func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchMoved(toPoint: t.location(in: self)) }
    }
    
    override public func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchUp(atPoint: t.location(in: self)) }
    }
    
    override public func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchUp(atPoint: t.location(in: self)) }
    }
    
    override public func update(_ currentTime: TimeInterval) {
        
        
        
        
        
        
    }
}




