import SpriteKit
import PlaygroundSupport

public class GameScene: SKScene {

    //lista de sementes
    var seeds = [Seed]()
    var lastUpdate = TimeInterval()
    
    var sun: SKSpriteNode!

    
    var nextNode: SKSpriteNode {
        childNode(withName: "Next") as! SKSpriteNode
    }
    override public func didMove(to view: SKView) {
        sun = childNode(withName: "sun")as? SKSpriteNode
        
        // some e aparece
        let fadeOut = SKAction.fadeOut(withDuration: 2)
        let wait = SKAction.wait(forDuration: 1)
        let fadeIn = SKAction.fadeIn(withDuration: 2)
        
        let sequence = SKAction.sequence([fadeOut, wait, fadeIn, wait])
        
        let loop = SKAction.repeatForever(sequence)
        
        sun.run(loop)
        nextNode.zPosition = 3
        nextNode.alpha = 0
        self.run(.wait(forDuration: 2)){
            self.nextNode.run(.fadeAlpha(to: 1, duration: 0.5))
        }
        // self.run(.wait(forDuration: 0.7)){
             //self.glicose.run(.fadeAlpha(to: 1, duration: 0.5))

    }

    @objc static override public var supportsSecureCoding: Bool {
        // SKNode conforms to NSSecureCoding, so any subclass going
        // through the decoding process must support secure coding
        get {
            return true
        }
    }

    func touchDown(atPoint pos : CGPoint) {
        // altura do chao
        if pos.y > -270 {
            createSeed(pos: pos)
        }
        
        if nextNode.contains(pos) && nextNode.alpha == 1{
            PlaygroundPage.current.navigateTo(page: .next)
        }
        
        //if botao.cont (pos)  && botao. alpha == 1
        
        //PlaygroundPage.current.navigateTo(page: .next)
        
    }

    func touchMoved(toPoint pos : CGPoint) {
      
    }

    func touchUp(atPoint pos : CGPoint) {
      
    }

    override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchDown(atPoint: t.location(in: self)) }
    }

    override public func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchMoved(toPoint: t.location(in: self)) }
    }

    override public func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchUp(atPoint: t.location(in: self)) }
    }

    override public func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchUp(atPoint: t.location(in: self)) }
    }

    override public func update(_ currentTime: TimeInterval) {
           
           // calculo do Delta Time
           // currentTime é o tempo que passou desde que o tempo foi inicializado
           //deltaTime é o tempo que passou de um frame e outro
           
           // pula o primeiro pq nao está armazenado
           if lastUpdate == 0 {
               lastUpdate = currentTime
               return
           }
           let deltaTime = currentTime - lastUpdate
           lastUpdate = currentTime
           
           
   //        // nil é nulo
   //        if seed != nil {
   //            seed.update(deltaTime: deltaTime)
   //        }
           
           
           // para cada semente da lista de sementes
           for seed in seeds{
               seed.update(deltaTime: deltaTime)
           }
              
       }
       
       
       
       // falicilar no tonw donw
       // chama a funcao e coloca parametros sempre dentro dos ()
       //(nome: tipo)
       // escopo da funcao {}
       func createSeed(pos: CGPoint){
           let seed = Seed(position: pos, scene: self)
           // gera uma nova e coloca na lista
           seeds.append(seed)
       
           
       }
   }

   public func + (left: CGPoint, right: CGPoint) -> CGPoint {
       return CGPoint(x: left.x + right.x, y: left.y + right.y)
   }


        
        


