import Foundation
import SpriteKit

public class Stalk {
    var startPoint = CGPoint()
    var angle = CGFloat()
    var totalLenght = CGFloat(250)
    var currentLenght = CGFloat()
    var speed = CGFloat(40)
    
    // variavel booleana -  so guarda T ou F
    var inShadow = true
    var status = StalkStatus.stalk1
    
 
    var currentLenghtCurve = CGFloat(0)
    
    
    // isso é o caule
    var lineStalk = SKShapeNode()
    
    
    // cria emoji
    
    
    
    // 3 seguimentos
    var lineStalk2 = SKShapeNode()
    var lineStalkCurve = SKShapeNode()

    
    var scene: SKScene
    
    // ? propriedade opcional - verefica se existe
    var leaf: Leaf?
    
    
    // label
    var emojiLabel = SKLabelNode()
    
    
    init(scene: SKScene, startPoint: CGPoint){
        self.scene = scene
    
        // o startPoint do caule é o startPoint da raiz level 0
        self.startPoint = startPoint
        //self.angle = CGFloat.random(in: 0...(CGFloat.pi * 0.5))
        self.angle = CGFloat.pi * 0.5
        
        let width = CGFloat(7.5)
        
        totalLenght = CGFloat.random(in: 100...250)
        
        
        emojiLabel.position = CGPoint(x: 1000000, y: 0)
        scene.addChild(emojiLabel)
        
        
        
        // teste if com luz e sem 
        if startPoint.x < -69 {
            // teste do if
            lineStalk.strokeColor = #colorLiteral(red: 0.9215686275, green: 0.9529411765, blue: 0.831372549, alpha: 1)
            lineStalk2.strokeColor = #colorLiteral(red: 0.9215686275, green: 0.9529411765, blue: 0.831372549, alpha: 1)
            lineStalkCurve.strokeColor = #colorLiteral(red: 0.9215686275, green: 0.9529411765, blue: 0.831372549, alpha: 1)
            
            lineStalk2.lineCap = .round

            lineStalk.lineWidth = width * 0.6
            lineStalk2.lineWidth = width * 0.6
            lineStalkCurve.lineWidth = width * 0.6
            speed = 90
            
            // * -1 -> 0 a 320
            // +10 -> 10 a 330
            // metada do start point -. matematicamente * 0.5 * -1 = * -0.5
            let minLenght = startPoint.x * -0.1
            let maxLenght = minLenght + 20
            totalLenght = CGFloat.random(in: minLenght...maxLenght)
            inShadow = true
    
            status = .stalk1
            scene.addChild(lineStalk2)
            scene.addChild(lineStalkCurve)
            
            
            emojiLabel.text =  "😰"
            
            
        }else {
            // separar em dois 
            lineStalk.strokeColor = #colorLiteral(red: 0.262745098, green: 0.5490196078, blue: 0, alpha: 1)
            lineStalk.lineWidth = width
            speed = 40
            totalLenght = CGFloat.random(in: 50...100)
            lineStalk.lineCap = .round
            inShadow = false
            
            status = .vertical
            emojiLabel.text =  "😄"
        }
        
        scene.addChild(lineStalk)
    }
    func update(deltaTime: TimeInterval) {
        // esse leaf garante as duas folhas -  conjunto da obra
        if leaf != nil {
            leaf!.update(deltaTime: deltaTime)
        }
        
        
        // end position + 50 no y
        // if inShadow == true
        if inShadow {
            if status == .curve{
                // funcao para curva
                grownStalkCurve(deltaTime: deltaTime)
            }else{
                // se nao funcao para ir reto
                // ta na sombra mas nao em curva
                grownStalk(deltaTime: deltaTime)
            }
            
            
        }else{
            // tá no sol
            grownStalk(deltaTime: deltaTime)
        }
        
        
        
        
    }
    
    func grownStalk(deltaTime: TimeInterval){
        if currentLenght >= totalLenght{
            return
        }
        
        currentLenght += CGFloat(deltaTime) * speed
        // vefericar se atingiu o tamanho total
        if currentLenght > totalLenght{
            currentLenght = totalLenght
        }
   
        //criou o caminho
        let path = CGMutablePath()
        path.move(to: startPoint)
        let vector = newVector(angle: angle, distance: currentLenght)
            
        let endPoint = startPoint + vector
        path.addLine(to: endPoint)
        
        emojiLabel.position = CGPoint(x: endPoint.x, y: (endPoint.y + 50))
        
        // verefica qual caminho seguir dependendo do tipo do caule que está 
        if status == .stalk1 || status == .vertical {
            lineStalk.path = path
        }else if status == .stalk2 {
            lineStalk2.path = path
        }
        
        
    
        if currentLenght == totalLenght{
           
            if inShadow{
                if status == .stalk1{
                    status = .curve
                    startPoint = endPoint
                    
                    
                }else if status == .stalk2{
                    leaf = Leaf(scene: scene, startPoint: endPoint)
                    emojiLabel.text = "🥰"
                }
                
                
                
            }else{
                // ta no sol
                leaf = Leaf(scene: scene, startPoint: endPoint)
               
                
            }
            
            
        }
    }
    
    
    func grownStalkCurve(deltaTime: TimeInterval){
        currentLenghtCurve += 0.003
        let path = CGMutablePath()
        path.move(to: startPoint)
        let radius = CGFloat(100)
        let center = CGPoint(x: startPoint.x + radius, y: startPoint.y)
        // pi = 180 pra radi
        let startAngle = CGFloat.pi
        
        // 135 graus 0.75 pi -> linha de 45 graus de inclinacao
        var endAngle =  CGFloat.pi - currentLenghtCurve * CGFloat.pi * 0.75
        
        if endAngle < CGFloat.pi * 0.75 {
            
            endAngle = CGFloat.pi * 0.75
        }
        
        let endPoint = CGPoint(x: (center.x + cos(endAngle) * radius), y: (center.y + sin(endAngle) * radius))
        
        emojiLabel.position = CGPoint(x: endPoint.x, y: (endPoint.y + 50))
        //clockwise sentido de crescimento horario ou anti
        path.addArc(center: center, radius: radius, startAngle: startAngle, endAngle: endAngle, clockwise: true)
        
        // caminho = path, segue o caminho
        lineStalkCurve.path = path
        
        if endAngle == CGFloat.pi * 0.75{
           
            status = .stalk2
            let angle = CGFloat.pi * 0.25
            let startX = startPoint.x + 100 - cos(angle) * 100
            let startY = startPoint.y + sin(angle) * 100
            startPoint = CGPoint(x: startX, y: startY)
            
            // dobrou
            // caclulo para chegar no sol
            totalLenght = (-startX / cos(angle)) + CGFloat.random(in: -30...30)
            self.angle = angle
            
            currentLenght = 0
            
            
        }
        
        
    }
    
    
    func newVector(angle: CGFloat, distance: CGFloat) -> CGPoint {
        return CGPoint(x: cos(angle) * distance, y: sin(angle) * distance)
    }
    // enumerador
    //só para esta classe
    enum StalkStatus {
        case stalk1
        case curve
        case stalk2
        case vertical
    }

    
    
}


