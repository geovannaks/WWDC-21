//
//  GameScene3.swift
//  BookCore
//
//  Created by Geovanna Kasemirinski da Silva on 14/04/21.


import Foundation
import SpriteKit
import PlaygroundSupport


public class GameScene3: SKScene {
  
    var seed3: SKSpriteNode {
        childNode(withName: "seed3") as! SKSpriteNode
    }
    var milho3: SKSpriteNode {
        childNode(withName: "milho3") as! SKSpriteNode
    }
    var redC: SKSpriteNode {
        childNode(withName: "redC") as! SKSpriteNode
    }
    
    
    var parts: SKSpriteNode {
        childNode(withName: "PartsSeed") as! SKSpriteNode
    }
    
    var cornSeed: SKSpriteNode {
        childNode(withName: "cornSeed") as! SKSpriteNode
    }
    
    var nextNode: SKSpriteNode {
        childNode(withName: "Next") as! SKSpriteNode
    }
   
    

    override public func didMove(to view: SKView) {
        backgroundColor = .init(red: 249, green: 247, blue: 247, alpha: 1)
        
        nextNode.alpha = 0
        redC.alpha = 0
        seed3.alpha = 0
        milho3.alpha = 1

        self.redC.run(.fadeAlpha(to: 1, duration: 0.5)) {
            self.run(.wait(forDuration: 0.5)){
                self.seed3.run(.fadeAlpha(to: 1, duration: 0.5)){
                    self.run(.wait(forDuration: 0.5)){
                        self.nextNode.run(.fadeAlpha(to: 1, duration: 0.5)){
                            
                        }
                    }
                }
            }
        }

        

    }

    @objc static override public var supportsSecureCoding: Bool {
        // SKNode conforms to NSSecureCoding, so any subclass going
        // through the decoding process must support secure coding
        get {
            return true
        }
    }

    func touchDown(atPoint pos : CGPoint) {
     
        if nextNode.contains(pos){
// named -> proxima tela
            let scene = GameScene31(fileNamed: "GameScene31")!
            scene.scaleMode = .aspectFit
            self.view!.presentScene(scene)
            self.removeFromParent()
            
        }



    }

    func touchMoved(toPoint pos : CGPoint) {

    }

    func touchUp(atPoint pos : CGPoint) {

    }

    override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchDown(atPoint: t.location(in: self)) }
    }

    override public func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchMoved(toPoint: t.location(in: self)) }
    }

    override public func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchUp(atPoint: t.location(in: self)) }
    }

    override public func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchUp(atPoint: t.location(in: self)) }
    }

    override public func update(_ currentTime: TimeInterval) {






       }
   }
