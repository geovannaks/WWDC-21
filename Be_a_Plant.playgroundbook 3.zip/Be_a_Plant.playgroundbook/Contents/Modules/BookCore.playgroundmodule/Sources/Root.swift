import Foundation
import SpriteKit


public class Root {
    //point x e Y - coordenada
    var startPoint = CGPoint()
    //float só um numero
    var angle = CGFloat()
    //Até onde ela vai chegar
    var totalLenght = CGFloat(30)
    // Tamanho atual
    var currentLenght = CGFloat()
    var level = Int()
    
    var speed = CGFloat(30)
    //representacao grafica
    var lineNode = SKShapeNode()
    
    //receber uma cena usa :
    // : existe mas ainda sem definicao
    var scene: SKScene
    
    
    // ? pode ser nulo
    // ! eu garanto que o objeto nao vai ser nulo quando eu precisar
    var branch1: Root?
    var branch2: Root?
    
    // funcao de inicializacao
    init(scene: SKScene, startPoint: CGPoint, level: Int) {
        
        //self pq já tem uma com o mesmo nome
        self.scene = scene
        self.level = level
        self.startPoint = startPoint
        
        self.angle = CGFloat.random(in: 0...(CGFloat.pi * 0.5)) - CGFloat.pi * 0.75
        
        let width = CGFloat(7 - level)
        
        lineNode.lineWidth = width
        
        
        lineNode.alpha = width / CGFloat(7)
        
        var color: UIColor
        if level == 0{
            color = #colorLiteral(red: 0.1875726879, green: 0.1233095601, blue: 0.02898368239, alpha: 1)
        } else if level == 1{
            color = #colorLiteral(red: 0.3077899516, green: 0.2065315545, blue: 0.0492675826, alpha: 1)
        }else if level == 2{
            color = #colorLiteral(red: 0.4100152254, green: 0.2550860643, blue: 0.1195563003, alpha: 1)
        }else if level == 3{
            color = #colorLiteral(red: 0.4198323786, green: 0.2641606033, blue: 0.1357874572, alpha: 1)
        }else if level == 4{
            color = #colorLiteral(red: 0.4038254023, green: 0.270373702, blue: 0.1608091295, alpha: 1)
        }else if level == 5{
            color = #colorLiteral(red: 0.4739832282, green: 0.3397285938, blue: 0.2205374539, alpha: 1)
        }else if level == 6{
            color = #colorLiteral(red: 0.5010824203, green: 0.3881129622, blue: 0.2713399827, alpha: 1)
        }else{
            color = #colorLiteral(red: 0.4666666687, green: 0.7647058964, blue: 0.2666666806, alpha: 1)
        }
        
        lineNode.strokeColor = color
        scene.addChild(lineNode)
        // vaid ar boa 
    }
    // deltatime -> tempo que passou entre um update e outro
    func update(deltaTime: TimeInterval) {
        

        //verefica se as raizes filhas existem
        if branch1 != nil {
            branch1!.update(deltaTime: deltaTime)
        }
        
        if branch2 != nil {
            branch2!.update(deltaTime: deltaTime)
        }
        
        //condicao para verificacao se a raiz atingiu o tamanho maximo 
        if currentLenght >= totalLenght{
            return
        }
            
        
        // qualquer processador vai ter a mesma velocidade
        currentLenght += CGFloat(deltaTime) * speed
        // vefericar se atingiu o tamanho total
        if currentLenght > totalLenght{
            currentLenght = totalLenght
        }
        
        let path = CGMutablePath()
        path.move(to: startPoint)
        let vector = newVector(angle: angle, distance: currentLenght)
            
        let endPoint = startPoint + vector
        path.addLine(to: endPoint)
        lineNode.path = path
        
        
        //raiz
        if currentLenght >= totalLenght {
            if level < 6 {
                branch1 = Root(scene: scene, startPoint: endPoint, level: level + 1)
                branch2 = Root(scene: scene, startPoint: endPoint, level: level + 1)
            }
        }
        
    }
    
    
    func newVector(angle: CGFloat, distance: CGFloat) -> CGPoint {
        return CGPoint(x: cos(angle) * distance, y: sin(angle) * distance)
    }
}

