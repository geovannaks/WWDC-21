import Foundation
import SpriteKit

public class Seed {
    // semente tem uma posicao
    var position = CGPoint()
    var root: Root!

    var stalk: Stalk!
    
    // representacao da semente
    var seed: SKSpriteNode
    
    
    // funcao de inicializacao
    
    init(position: CGPoint, scene: SKScene) {
        
        
        // fisica para semente cair
        seed = SKSpriteNode(imageNamed: "Seedcorn")
        seed.setScale(0.5)
        seed.position = position
        
        //quando clicae entra na cena
        scene.addChild(seed)
        
        // altura do solo
        let groundHigh = CGFloat(-270)
        // calculo da onde vai cair
        let high = position.y - groundHigh
        let speedSeed = CGFloat(250)
        let duration = TimeInterval(high / speedSeed)
        
        let fallAction = SKAction.moveBy(x: 0, y: -high, duration: duration)
        
        // cair acelerando
        fallAction.timingMode = .easeIn
        
        seed.zPosition = 2
        
        seed.run(fallAction){
            self.root = Root(scene: scene, startPoint: self.seed.position, level: 0)
            self.stalk = Stalk(scene: scene, startPoint: self.seed.position)
            
            self.seed.run(SKAction.fadeOut(withDuration: 3))
            
        }
        
        
    }
   
    
    
    // semente chama o update da raiz 
    func update (deltaTime: TimeInterval){
        if root != nil{
            root.update(deltaTime: deltaTime)
        }
        
        if stalk != nil {
            stalk.update(deltaTime: deltaTime)
        }
    }
}
