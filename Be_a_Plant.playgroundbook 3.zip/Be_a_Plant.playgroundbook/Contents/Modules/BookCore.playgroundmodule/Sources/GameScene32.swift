//
//  GameScene32.swift
//  BookCore
//
//  Created by Geovanna Kasemirinski da Silva on 15/04/21.
//

import Foundation
import SpriteKit

import PlaygroundSupport


public class GameScene32: SKScene{
    
    var cornSeedBig: SKSpriteNode {
        childNode(withName: "CornSeedBig") as! SKSpriteNode
    }
    
    var nextNode: SKSpriteNode {
        childNode(withName: "Next") as! SKSpriteNode
    }
    
    var positionsPoint: [ CGPoint ]? {
        childNode(withName: "Positions")?.children.map { $0.position }
    }
    
    // lazy é criada depois
    lazy var positions: [CGPoint]? = {
       positionsPoint
    }()
    
    
    let tap = SKLabelNode(text: "Tap here")
    
    var tapCount = 0
    
    var words = [
       
        SKLabelNode(text: "Strength"),
        SKLabelNode(text: "Resilience"),
        SKLabelNode(text: "Happiness"),
        SKLabelNode(text: "Gratefulness"),
        SKLabelNode(text: "Be strong"),
        SKLabelNode(text: "Adaptation"),
        SKLabelNode(text: "Flexibility"),
        
    ]
    
    override public func didMove(to view: SKView){
        backgroundColor = .init(red: 249, green: 247, blue: 247, alpha: 1)
        
        nextNode.alpha = 0
        
        tap.alpha = 1
        //tap.text = "Tap here"
        tap.fontName = "Montserrat"
        tap.fontColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        tap.fontSize = 28
        tap.position = CGPoint(x: 1, y: 0)
        addChild(tap)
    }
    
    
    @objc static override public var supportsSecureCoding: Bool {
        // SKNode conforms to NSSecureCoding, so any subclass going
        // through the decoding process must support secure coding
        get {
            return true
        }
    }
    
    func touchDown(atPoint pos : CGPoint){
        
        
        if nextNode.contains(pos) && nextNode.alpha == 1 {
            // named -> proxima tela
            let scene = GameScene33(fileNamed: "GameScene33")!
            scene.scaleMode = .aspectFit
            self.view!.presentScene(scene)
            self.removeFromParent()
            
        }
        
        if cornSeedBig.contains(pos){
            
            if let label = words.randomElement(){
                // pode nao existir
                label.fontName = "Montserrat"
                label.fontColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
                label.fontSize = 26
                label.alpha = 0
                
                
                // remover todas as palavras em que o texto dela seja igual ao texto da label
                words.removeAll(where: { $0.text == label.text })
                
                // ! pode ou nao existir, ele EXISTE sempre pq vc ta dizendo que ele existe
                addChild(label)
                
                label.position = CGPoint.zero
                if let position = positions?.randomElement(){
                    label.run(.move(to: position, duration: 0.5))
                    label.run(.fadeIn(withDuration: 0.5))
                    positions?.removeAll(where: { $0 == position})
                    
                }
                
            }
            
            tapCount += 1
            if tapCount == 7{
                tap.run(.fadeOut(withDuration: 0.4))
                nextNode.run(.fadeIn(withDuration: 0.4))
            }
            
            
            
        }
        
        
    }
    override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchDown(atPoint: t.location(in: self)) }
    }
}
