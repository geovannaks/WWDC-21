/*:

![Uma imagem explicativa](Bestrong.png)



 # The "easy" way

 - Note: For the best experience, please play it on landscape split mode.


 ---
### The plant in the light and good soil fertility grew less, with stalk thick and green. Why?
 ---


 Because it receive light, it make photosynthesis. In this process the plant catches sun light and carbon dioxide, can do metabolic processes that create a type of sugar, called glucose. With glucose the plant can grow. Moreover releases oxygen. It was born in the most favorable environment for her growth there was no obstacle that could hinder the development and that is why it was always strong.


 ---


**Drag** the sun close to the leaf and watch it grow.


 ---


And **tap** in next to see the plant without light.
*/
 
 //#-hidden-code
import PlaygroundSupport
import SpriteKit
import UIKit
import BookCore

let sceneView = SKView(frame: CGRect(x: 0, y: 0, width: 640, height: 860))
if let scene = GameScene2(fileNamed: "GameScene2") {
    scene.scaleMode = .aspectFit
    sceneView.presentScene(scene)
}

PlaygroundPage.current.liveView = sceneView
PlaygroundPage.current.needsIndefiniteExecution = true
 //#-end-hidden-code

