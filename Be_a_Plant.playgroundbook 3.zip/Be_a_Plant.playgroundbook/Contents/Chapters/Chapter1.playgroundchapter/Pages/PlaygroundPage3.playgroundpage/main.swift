/*:

![Uma imagem explicativa](Bestrong.png)


 # The "hard" way
 
 - Note: For the best experience, please play it on landscape split mode.

 
 ---
### But the left plant grew in a different form, but why?
 ---
 
 
Without photosynthesis, it can’t produce its own food. So it looks like so thin and whitish. However, yet it survives. Because takes off the strength that it needs of a reservation, inside of the seed, we called endosperm. Besides, inside the seed has the embryo, that contains radicle, that would be a root start and the primary leaf waiting the moment for coming out, called plumule. Both of the plants, the left and the right one, the have endosperm in their seeds, but the plant without light used her maximum reserve of nutrients to grow, it was resilient, it overcame the difficulties and also became a beautiful plant.
 
 
 ---
 
 
**Tap** in next and find out about the parts of the seed.
 
 
 ---
 
 
**Meet what else have insede its.**
*/

//#-hidden-code
import PlaygroundSupport
import SpriteKit
import UIKit
import BookCore

let sceneView = SKView(frame: CGRect(x: 0, y: 0, width: 640, height: 860))
if let scene = GameScene3(fileNamed: "GameScene3") {
    scene.scaleMode = .aspectFit
    sceneView.presentScene(scene)
}


PlaygroundPage.current.liveView = sceneView
//#-end-hidden-code

