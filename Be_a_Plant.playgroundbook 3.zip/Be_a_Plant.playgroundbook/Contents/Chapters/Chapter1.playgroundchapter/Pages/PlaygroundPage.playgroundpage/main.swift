/*:

![Uma imagem explicativa](Bestrong.png)
 

 # Be strong! Be a plant!

 - Note: For the best experience, please play it on landscape split mode.


 ---
### Do you know what is resilience?
 ---


According to the dictionary, the word resilience has two meanings. The first one, is about physics:

 ---

**"Property that some bodies have of returning to their original shape after being subjected to an elastic deformation”**

 ---

 and the second, the figurative meaning:

 ---

**"The ability to recover easily or adapt to bad luck or changes”.**

 ---

Resilience, is the capacity to overcome adversity and emerging even stronger than before.
Do you know some adversity happen to the plants too?


 ---


**Tap** in diferente spots to throw the seeds in the soil and find out how plants are resilient its unic way.

 
 ---


**Tap** in next and understand the process.
 */

//#-hidden-code
import PlaygroundSupport
import SpriteKit
import UIKit
import BookCore

let sceneView = SKView(frame: CGRect(x: 0, y: 0, width: 640, height: 860))
if let scene = GameScene(fileNamed: "GameScene") {
    scene.scaleMode = .aspectFit
    sceneView.presentScene(scene)
}

PlaygroundPage.current.liveView = sceneView
PlaygroundPage.current.needsIndefiniteExecution = true
//#-end-hidden-code

